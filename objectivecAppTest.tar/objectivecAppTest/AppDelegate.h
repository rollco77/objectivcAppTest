//
//  AppDelegate.h
//  objectivecAppTest
//
//  Created by suhwan on 2022/03/21.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

